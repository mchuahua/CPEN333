#include <iostream>
#include <process.h>
#include <Windows.h>
using namespace std;

struct Arg {
	int iterator =0;
	string phrase = "placeholder";
};

UINT __stdcall ChildThread1(void* args)	// thread function
{
	Arg inputargs = *(Arg*)(args);

	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase <<", this is Child Process 1"<< endl;
	}
	return 0;
}

UINT __stdcall ChildThread2(void* args)	// thread function
{
	Arg inputargs = *(Arg*)(args);

	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase << ", this is Child Process 2" << endl;
	}
	return 0;
}

UINT __stdcall ChildThread3(void* args)	// thread function
{
	Arg inputargs = *(Arg*)(args);

	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase << ", this is Child Process 3" << endl;
	}
	return 0;
}

int main()
{
	HANDLE p1, p2, p3;
	UINT p1threadID, p2threadID, p3threadID;

	Arg p1args;
	p1args.iterator = 10;
	p1args.phrase = "Varun";

	Arg p2args;
	p2args.iterator = 20;
	p2args.phrase = "Martin";

	Arg p3args;
	p3args.iterator = 30;
	p3args.phrase = "Paul";

	cout << "Creating Child Processes.....\n";
	p1 = (HANDLE)(_beginthreadex(NULL, 0, ChildThread1, &p1args, 0, &p1threadID));
	if (!p1) {
		cout << "Error creating process 1"<<endl;
		return -1;
	}
	else cout << "Process 1 created\n";
	p2 = (HANDLE)(_beginthreadex(NULL, 0, ChildThread2, &p2args, 0, &p2threadID));
	if (!p2) {
		cout << "Error creating process 2" << endl;
		return -1;
	}
	else cout << "Process 2 created\n";

	p3 = (HANDLE)(_beginthreadex(NULL, 0, ChildThread3, &p3args, 0, &p3threadID));
	if (!p3) {
		cout << "Error creating process 3" << endl;
		return -1;
	}
	else cout << "Process 3 created\n";

	//SUSPEND ALL
	cout << "Suspending all processes here\n";
	
	UINT p1suspend = SuspendThread(p1);
	if (p1suspend == 0xffffffff) {
		cout << "Cannot resume process 1";
	}

	UINT p2suspend = SuspendThread(p2);
	if (p2suspend == 0xffffffff) {
		cout << "Cannot resume process 2";
	}

	UINT p3suspend = SuspendThread(p3);
	if (p3suspend == 0xffffffff) {
		cout << "Cannot resume process 3";
	}

	cout << "Child Process Activated.....\n";

	//RESUME AND TERMINATE PROCESSES IN ORDER
	cout << "\nWaiting For Child1 to Terminate.....\n";
	UINT p1resume = ResumeThread(p1);
	if (p1resume == 0xffffffff) {
		cout << "Cannot resume process 1";
	}
	UINT p1Result = WaitForSingleObject(p1, INFINITE);
	if (p1Result==WAIT_FAILED) {
		cout << "Error terminating process 1" << endl;
		return -1;
	}
	cout << "Child1 Terminated\n";

	cout << "\nWaiting For Child2 to Terminate.....\n";
	UINT p2resume = ResumeThread(p2);
	if (p2resume == 0xffffffff) {
		cout << "Cannot resume process 2";
	}
	UINT p2Result = WaitForSingleObject(p2, INFINITE);
	if (p2Result == WAIT_FAILED) {
		cout << "Error terminating process 2" << endl;
		return -1;
	}
	cout << "Child2 Terminated\n";
	
	cout << "\nWaiting For Child3 to Terminate.....\n";
	UINT p3resume = ResumeThread(p3);
	if (p3resume == 0xffffffff) {
		cout << "Cannot resume process 3";
	}
	UINT p3Result = WaitForSingleObject(p3, INFINITE);
	if (p3Result == WAIT_FAILED) {
		cout << "Error terminating process 3" << endl;
		return -1;
	}
	cout << "Child3 Terminated\n";

	return 0;
}
#include <iostream>
#include <process.h>
#include <Windows.h>
#include <thread>
using namespace std;

struct Arg {
	int iterator =0;
	string phrase = "placeholder";
};

int ChildThread1(Arg inputargs)	// thread function
{
	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase <<", this is Child Process 1"<< endl;
	}
	return 0;
}

int ChildThread2(Arg inputargs)	// thread function
{
	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase << ", this is Child Process 2" << endl;
	}
	return 0;
}

int ChildThread3(Arg inputargs)	// thread function
{
	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase << ", this is Child Process 3" << endl;
	}
	return 0;
}

int main()
{
	thread *p1, *p2, *p3;

	Arg p1args;
	p1args.iterator = 10;
	p1args.phrase = "Varun";

	Arg p2args;
	p2args.iterator = 20;
	p2args.phrase = "Martin";

	Arg p3args;
	p3args.iterator = 30;
	p3args.phrase = "Paul";

	//CREATE THREADS
	cout << "Creating Child Processes.....\n";
	p1 = new thread(ChildThread1, p1args);
	cout << "Process 1 created\n";
	HANDLE p1_handle = p1->native_handle();

	p2 = new thread(ChildThread2, p2args);
	cout << "Process 2 created\n";
	HANDLE p2_handle = p2->native_handle();

	p3 = new thread(ChildThread3, p3args);
	cout << "Process 3 created\n";
	HANDLE p3_handle = p3->native_handle();

	//SUSPEND ALL
	cout << "Suspending all processes here\n";
	
	UINT p1suspend = SuspendThread(p1_handle);
	if (p1suspend == 0xffffffff) {
		cout << "Cannot resume process 1";
	}

	UINT p2suspend = SuspendThread(p2_handle);
	if (p2suspend == 0xffffffff) {
		cout << "Cannot resume process 2";
	}

	UINT p3suspend = SuspendThread(p3_handle);
	if (p3suspend == 0xffffffff) {
		cout << "Cannot resume process 3";
	}

	cout << "Child Process Activated.....\n";

	//RESUME AND TERMINATE THREADS IN ORDER
	cout << "\nWaiting For Child1 to Terminate.....\n";
	UINT p1resume = ResumeThread(p1_handle);
	if (p1resume == 0xffffffff) {
		cout << "Cannot resume process 1";
	}
	p1->join();
	delete p1;
	cout << "Child1 Terminated\n";

	cout << "\nWaiting For Child2 to Terminate.....\n";
	UINT p2resume = ResumeThread(p2_handle);
	if (p2resume == 0xffffffff) {
		cout << "Cannot resume process 2";
	}
	p2->join();
	delete p2;
	cout << "Child2 Terminated\n";
	
	cout << "\nWaiting For Child3 to Terminate.....\n";
	UINT p3resume = ResumeThread(p3_handle);
	if (p3resume == 0xffffffff) {
		cout << "Cannot resume process 3";
	}
	p3->join();
	delete p3;
	cout << "Child3 Terminated\n";

	return 0;
}
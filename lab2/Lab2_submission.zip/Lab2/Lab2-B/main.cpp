#include <iostream>
#include <process.h>
#include <Windows.h>
using namespace std;

int main()
{
	cout << "Creating Child Processes.....\n";
	string p1_name = "Child1.exe";
	string p2_name = "Child2.exe";
	string p3_name = "Child3.exe";

	//PROCESS 1
	PROCESS_INFORMATION p1_Info;
	STARTUPINFO	p1_StartupInfo = {
		sizeof(STARTUPINFO) ,
		NULL ,			// reserved
		NULL ,			// ignored in console applications
		(char*)(p1_name.c_str()) ,	// displayed in title bar for console applications
		0,0,			// dwx, dwy, offset of top left of new window relative to top left of screen in pixel
						// flags below must specify STARTF_USEPOSITION. Ignored for console apps'
		0,0,			// dwxsize, dwysize: Width and height of the window if new window specified
						// must use flags STARTF_USESIZE. Ignored for console apps'
		0,0,			// size of console in characters, only if STARTF_USECOUNTCHARS flag specified, 
						// Ignored for console apps
		0,				// Colour control, for background and text. Ignored for console apps
		0,				// Flags. Ignored for console applications
		0,				// ignored unless showwindow flag set
		0 ,	NULL, 0,0,0			// stdin, stdout and stderr handles (inherited from parent)
	};
	UINT p1_flags = NORMAL_PRIORITY_CLASS;// | CREATE_NEW_CONSOLE; //| CREATE_SUSPENDED; ---- modify here for these properties

	BOOL p1_success = CreateProcess(NULL,	// application name
		(char*)(p1_name.c_str()),			// Command line to the process if you want to pass one to main() in the process
		NULL,			// process attributes
		NULL,			// thread attributes
		TRUE,			// inherits handles of parent
		p1_flags,			// Priority and Window control flags,
		NULL,			// use environent of parent
		NULL,			// use same drive and directory as parent
		&p1_StartupInfo,	// controls appearance of process (see above)
		&p1_Info			// Stored process handle and ID into this object
	);

	if (!p1_success) {
		cout << "Unable to create new process 1\n";
		return -1;
	}
	else {
		cout << "Process 1 created\n";
	}

	//PROCESS 2
	PROCESS_INFORMATION p2_Info;
	STARTUPINFO	p2_StartupInfo = {
		sizeof(STARTUPINFO) ,
		NULL ,			// reserved
		NULL ,			// ignored in console applications
		(char*)(p2_name.c_str()) ,	// displayed in title bar for console applications
		0,0,			// dwx, dwy, offset of top left of new window relative to top left of screen in pixel
						// flags below must specify STARTF_USEPOSITION. Ignored for console apps'
		0,0,			// dwxsize, dwysize: Width and height of the window if new window specified
						// must use flags STARTF_USESIZE. Ignored for console apps'
		0,0,			// size of console in characters, only if STARTF_USECOUNTCHARS flag specified, 
						// Ignored for console apps
		0,				// Colour control, for background and text. Ignored for console apps
		0,				// Flags. Ignored for console applications
		0,				// ignored unless showwindow flag set
		0 ,	NULL, 0,0,0			// stdin, stdout and stderr handles (inherited from parent)
	};
	UINT p2_flags = NORMAL_PRIORITY_CLASS;// | CREATE_NEW_CONSOLE;// | CREATE_SUSPENDED; ---- modify here for these properties

	BOOL p2_success = CreateProcess(NULL,	// application name
		(char*)(p2_name.c_str()),			// Command line to the process if you want to pass one to main() in the process
		NULL,			// process attributes
		NULL,			// thread attributes
		TRUE,			// inherits handles of parent
		p2_flags,			// Priority and Window control flags,
		NULL,			// use environent of parent
		NULL,			// use same drive and directory as parent
		&p2_StartupInfo,	// controls appearance of process (see above)
		&p2_Info			// Stored process handle and ID into this object
	);

	if (!p2_success) {
		cout << "Unable to create new process 2\n";
		return -1;
	}
	else {
		cout << "Process 2 created\n";
	}

	//PROCESS 3
	PROCESS_INFORMATION p3_Info;
	STARTUPINFO	p3_StartupInfo = {
		sizeof(STARTUPINFO) ,
		NULL ,			// reserved
		NULL ,			// ignored in console applications
		(char*)(p3_name.c_str()) ,	// displayed in title bar for console applications
		0,0,			// dwx, dwy, offset of top left of new window relative to top left of screen in pixel
						// flags below must specify STARTF_USEPOSITION. Ignored for console apps'
		0,0,			// dwxsize, dwysize: Width and height of the window if new window specified
						// must use flags STARTF_USESIZE. Ignored for console apps'
		0,0,			// size of console in characters, only if STARTF_USECOUNTCHARS flag specified, 
						// Ignored for console apps
		0,				// Colour control, for background and text. Ignored for console apps
		0,				// Flags. Ignored for console applications
		0,				// ignored unless showwindow flag set
		0 ,	NULL, 0,0,0			// stdin, stdout and stderr handles (inherited from parent)
	};
	UINT p3_flags = NORMAL_PRIORITY_CLASS;// | CREATE_NEW_CONSOLE;// | CREATE_SUSPENDED; ----modify here for these properties

	BOOL p3_success = CreateProcess(NULL,	// application name
		(char*)(p3_name.c_str()),			// Command line to the process if you want to pass one to main() in the process
		NULL,			// process attributes
		NULL,			// thread attributes
		TRUE,			// inherits handles of parent
		p3_flags,			// Priority and Window control flags,
		NULL,			// use environent of parent
		NULL,			// use same drive and directory as parent
		&p3_StartupInfo,	// controls appearance of process (see above)
		&p3_Info			// Stored process handle and ID into this object
	);

	if (!p3_success) {
		cout << "Unable to create new process 3\n";
		return -1;
	}
	else {
		cout << "Process 3 created\n";
	}
	//Suspend all processes
	//Sleep(1000);

	UINT p1_susp = SuspendThread(p1_Info.hThread);
	if (p1_susp == 0xffffffff) {
		cout << "Unable to suspend Process 1\n";
		return -1;
	}
	else {
		cout << "Process 1 suspended\n";
	}

	UINT p2_susp = SuspendThread(p2_Info.hThread);
	if (p2_susp == 0xffffffff) {
		cout << "Unable to suspend Process 2\n";
		return -1;
	}
	else {
		cout << "Process 2 suspended\n";
	}

	UINT p3_susp = SuspendThread(p3_Info.hThread);
	if (p3_susp == 0xffffffff) {
		cout << "Unable to suspend Process 3\n";
		return -1;
	}
	else {
		cout << "Process 3 suspended\n";
	}

	Sleep(500);
	cout << "Child Processes Activated.....\n";

	//------------------------------------------------------------------------------------
	//Resume Process 1
	UINT p1_resume = ResumeThread(p1_Info.hThread);
	if (p1_resume == 0xffffffff) {
		cout << "Unable to resume Process 1\n";
		return -1;
	}
	else {
		cout << "\n**********************************************\nResuming Process 1\n";
	}

	cout << "Waiting For Child1 to Terminate.....\n";
	UINT p1_res = WaitForSingleObject(p1_Info.hThread, INFINITE); //WaitForProcess()
	if (p1_res == WAIT_FAILED) {
		cout << "Unable to wait to terminate process 1\n";
		return -1;
	}
	else {
		cout << "Terminated process 1\n";
		CloseHandle(p1_Info.hProcess); //to avoid handle leak
	}

	//------------------------------------------------------------------------------------
	//Resume Process 2
	UINT p2_resume = ResumeThread(p2_Info.hThread);
	if (p2_resume == 0xffffffff) {
		cout << "Unable to resume Process 2\n";
		return -1;
	}
	else {
		cout << "\n**********************************************\nResuming Process 2\n";
	}

	cout << "Waiting For Child2 to Terminate.....\n";
	UINT p2_res = WaitForSingleObject(p2_Info.hThread, INFINITE); //WaitForProcess()
	if (p1_res == WAIT_FAILED) {
		cout << "Unable to wait to terminate process 2\n";
		return -1;
	}
	else {
		cout << "Terminated process 2\n";
		CloseHandle(p2_Info.hProcess); //to avoid handle leak
	}

	//------------------------------------------------------------------------------------
	//Resume Process 3
	UINT p3_resume = ResumeThread(p3_Info.hThread);
	if (p3_resume == 0xffffffff) {
		cout << "Unable to resume Process 3\n";
		return -1;
	}
	else {
		cout << "\n**********************************************\nResuming Process 3\n";
	}

	cout << "Waiting For Child3 to Terminate.....\n";
	UINT p3_res = WaitForSingleObject(p3_Info.hThread, INFINITE); //WaitForProcess()
	if (p1_res == WAIT_FAILED) {
		cout << "Unable to wait to terminate process 3\n";
		return -1;
	}
	else {
		cout << "Terminated process 3\n";
		CloseHandle(p3_Info.hProcess); //to avoid handle leak
	}

	return 0;
}

//PART A CODE
/*
int main()
{
	cout << "Creating Child Processes.....\n";

	CProcess p1("Child1.exe",	// pathlist to child program executable				
		NORMAL_PRIORITY_CLASS,			// priority
		PARENT_WINDOW,						// process has its own window					
		ACTIVE							// process is active immediately
	);


	CProcess p2("Child2.exe",	// pathlist to child program executable				
		NORMAL_PRIORITY_CLASS,			// priority
		PARENT_WINDOW,						// process has its own window					
		ACTIVE							// process is active immediately
	);

	CProcess p3("Child3.exe varun 1.0",	// pathlist to child program executable	plus some arguments		
		NORMAL_PRIORITY_CLASS,			// priority
		PARENT_WINDOW,						// process has its own window					
		ACTIVE
	);

	cout << "Child Processes Activated.....\n";

	cout << "Waiting For Child1 to Terminate.....\n";
	p2.Suspend();
	p3.Suspend();
	p1.WaitForProcess();

	cout << "Waiting For Child2 to Terminate.....\n";
	p2.Resume();
	p2.WaitForProcess();					// wait for the child process to end

	cout << "Waiting For Child3 to Terminate.....\n";
	p3.Resume();
	p3.WaitForProcess();					// wait for the child process to end

	return 0;
}
*/
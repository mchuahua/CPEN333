#include 	"rt.h"
#include <iostream>
using namespace std;

struct Arg {
	int iterator =0;
	string phrase = "placeholder";
};

UINT __stdcall ChildThread1(void* args)	// thread function
{
	Arg inputargs = *(Arg*)(args);

	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase <<", this is Child Process 1"<< endl;
	}
	return 0;
}

UINT __stdcall ChildThread2(void* args)	// thread function
{
	Arg inputargs = *(Arg*)(args);

	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase << ", this is Child Process 2" << endl;
	}
	return 0;
}

UINT __stdcall ChildThread3(void* args)	// thread function
{
	Arg inputargs = *(Arg*)(args);

	for (int i = 0; i < inputargs.iterator; i++) {
		cout << "Hi " << inputargs.phrase << ", this is Child Process 3" << endl;
	}
	return 0;
}

int main()
{
	Arg p1args;
	p1args.iterator = 10;
	p1args.phrase = "Varun";

	Arg p2args;
	p2args.iterator = 20;
	p2args.phrase = "Martin";

	Arg p3args;
	p3args.iterator = 30;
	p3args.phrase = "Paul";

	cout << "Creating Child Processes.....\n";
	CThread p1(ChildThread1, SUSPENDED, &p1args);
	CThread p2(ChildThread2, SUSPENDED, &p2args);
	CThread p3(ChildThread3, SUSPENDED, &p3args);

	cout << "Child Process Activated.....\n";
	cout << "\nWaiting For Child1 to Terminate.....\n";
	p1.Resume();
	p1.WaitForThread();
	cout << "Child1 Terminated\n";

	cout << "\nWaiting For Child2 to Terminate.....\n";
	p2.Resume();
	p2.WaitForThread();
	cout << "Child2 Terminated\n";
	
	cout << "\nWaiting For Child3 to Terminate.....\n";
	p3.Resume();
	p3.WaitForThread();
	cout << "Child3 Terminated\n";

	return 0;
}
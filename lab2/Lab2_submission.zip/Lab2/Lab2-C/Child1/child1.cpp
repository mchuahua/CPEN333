#include "..\rt.h"

int main(int argc, char* argv[])
{
	int i;
	//argv[0] is path
	//argv[1] is phrase
	//argv[2] is int num

	for (i = 0; i < atoi(argv[2]); i++) {
		cout << "Hello " << argv[1] << " from child process 1...." << endl;
		Sleep(50);
	}

	return 0;		// exit child program by returning status value 0
				// Note we could also call exit(0) to achieve the same thing
}
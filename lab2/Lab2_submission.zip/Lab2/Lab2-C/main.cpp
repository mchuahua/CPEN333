#include "rt.h"			// change pathlist to this header file according to where it is stored

int main()
{
	cout << "Creating Child Processes.....\n";

	CProcess p1("Child1.exe Varun 200",	// pathlist to child program - says Hello Varun 200x 				
		NORMAL_PRIORITY_CLASS,			// priority
		OWN_WINDOW,						// process has its own window					
		ACTIVE							// process is active immediately
	);

	CProcess p2("Child2.exe Martin 250",	// pathlist to child program - says Hello Martin 250x		
		NORMAL_PRIORITY_CLASS,			// priority
		OWN_WINDOW,						// process has its own window					
		ACTIVE							// process is active immediately
	);

	CProcess p3("Child3.exe Paul 300",	// pathlist to child program - says Hello Paul 300x
		NORMAL_PRIORITY_CLASS,			// priority
		OWN_WINDOW,						// process has its own window					
		ACTIVE
	);

	cout << "Child Processes Activated.....\n";

	cout << "Waiting For Child1 to Terminate.....\n";
	p1.WaitForProcess();
	cout << "Child1 Terminated\n";

	cout << "Waiting For Child2 to Terminate.....\n";
	p2.WaitForProcess();					// wait for the child process to end
	cout << "Child2 Terminated\n";

	cout << "Waiting For Child3 to Terminate.....\n";
	p3.WaitForProcess();					// wait for the child process to end
	cout << "Child3 Terminated\n";

	return 0;
}
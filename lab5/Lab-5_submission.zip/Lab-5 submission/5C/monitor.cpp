#include "monitor.h"

monitor::monitor(string name){
	CM = new CMutex(string("Mutex") + name);
}

monitor::~monitor(){
	delete CM;
}

int __thiscall monitor::C1(void* args) {
	for (int i = 0; i < 1000; i++) {
		WriteToScreen(10, 20, string("Child 1 at"));
	}
	return 0;
}

int __thiscall monitor::C2(void* args) {
	for (int i = 0; i < 1000; i++) {
		WriteToScreen(10, 30, string("Child 2 at"));
	}
	return 0;
}

int __thiscall monitor::C3(void* args) {
	for (int i = 0; i < 1000; i++) {
		WriteToScreen(10, 40, string("Child 3 at"));
	}
	return 0;
}

int monitor::main() {
	ClassThread<monitor> C1(this, &monitor::C1, ACTIVE, NULL);			
	ClassThread<monitor> C2(this, &monitor::C2, ACTIVE, NULL);				
	ClassThread<monitor> C3(this, &monitor::C3, ACTIVE, NULL);				
	for (int i = 0; i < 1000; i++) {
		WriteToScreen(5, 5, "Part C Main thread");
	}
	C1.WaitForThread();		
	C2.WaitForThread();
	C3.WaitForThread();
	return 0;
}

void monitor::WriteToScreen(int x, int y, string input) {
	CM->Wait();
	MOVE_CURSOR(x, y);
	cout << input << " X:" << x << " Y:" << y;
	cout.flush();
	CM->Signal();
	Sleep(10);
}
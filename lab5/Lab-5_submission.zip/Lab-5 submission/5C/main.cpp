#include "rt.h"
#include "monitor.h"

int main(){
	monitor mon("ANamedMonitor");
	mon.Resume();
	mon.WaitForThread();
	return 0;
}
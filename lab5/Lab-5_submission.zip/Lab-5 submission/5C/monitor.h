#ifndef __monitor__
#define __monitor__

#include "rt.h"

class monitor : public ActiveClass{
public:
	monitor(string name);
	~monitor();
	int __thiscall C1(void* args);
	int __thiscall C2(void* args);
	int __thiscall C3(void* args);

private:
	void WriteToScreen(int x, int y, string input);
	CMutex* CM;
	int main();
};

#endif // !__monitor__

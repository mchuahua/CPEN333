#ifndef __soln1__
#define __soln1__

#include "rt.h"
#include <atomic>

class soln1 : public ActiveClass {
public:
	soln1();
	~soln1();
	int __thiscall C1(void* args);
	int __thiscall C2(void* args);
	int __thiscall C3(void* args);

private:
	atomic_flag flag;
	int main();

};

#endif // !__soln1__

#include "soln2.h"
#include <iostream>
using namespace std;

soln2::soln2() {
	CM = new CMutex("mutex");
}

soln2::~soln2() {
	delete CM;
}

int __thiscall soln2::C1(void* args) {
	for (int i = 0; i < 5; i++) {
		CM->Wait();
		MOVE_CURSOR(10, 20);
		cout << "Mutex Child Thread 1 ";
		cout.flush();
		CM->Signal();
	}
	return 0;
}

int __thiscall soln2::C2(void* args) {
	for (int i = 0; i < 5; i++) {
		CM->Wait();
		MOVE_CURSOR(10, 30);
		cout << "Mutex Child Thread 2 ";
		cout.flush();
		CM->Signal();
	}
	return 0;
}

int __thiscall soln2::C3(void* args) {
	for (int i = 0; i < 5; i++) {
		CM->Wait();
		MOVE_CURSOR(10, 40);
		cout << "Mutex Child Thread 3 ";
		cout.flush();
		CM->Signal();
	}
	return 0;
}

int soln2::main() {
	ClassThread<soln2> C1(this, &soln2::C1, ACTIVE, NULL);			// create the 3 other B1 Child Threads
	ClassThread<soln2> C2(this, &soln2::C2, ACTIVE, NULL);				// create the 3 other B1 Child Threads
	ClassThread<soln2> C3(this, &soln2::C3, ACTIVE, NULL);				// create the 3 other B1 Child Threads
	for (int i = 0; i < 5; i++) {
		CM->Wait();
		MOVE_CURSOR(5, 5);             	// move cursor to cords [x,y] = 5,5
		cout << "Main Mutex Thread  \n";
		cout.flush();
		CM->Signal();
	}
	C1.WaitForThread();				// wait for the 3 other B1 Child Threads to end
	C2.WaitForThread();
	C3.WaitForThread();
	//getchar();
	return 0;
}

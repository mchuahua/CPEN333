#include 	"rt.h"
#include "soln1.h"
#include "soln2.h"
#include <iostream>
using namespace std;

int main(){
	soln1 S1;
	S1.Resume();
	S1.WaitForThread();


	soln2 S2;
	S2.Resume();
	S2.WaitForThread();

	return 0;
}
#include "soln1.h"
#include <iostream>
using namespace std;

soln1::soln1(){
}

soln1::~soln1(){
}

int __thiscall soln1::C1(void* args) {
	for (int i = 0; i < 5; i++) {
		while (flag.test_and_set() == true);
		MOVE_CURSOR(10,20);             	
		cout<<"Atomic Child Thread 1";
		cout.flush();
		flag.clear();
	}
	return 0;
}

int __thiscall soln1::C2(void* args) {
	for (int i = 0; i < 5; i++) {
		while (flag.test_and_set() == true);
		MOVE_CURSOR(10,30);            
		cout << "Atomic Child Thread 2";
		cout.flush();
		flag.clear();
	}
	return 0;
}

int __thiscall soln1::C3(void* args) {
	for (int i = 0; i < 5; i++) {
		while (flag.test_and_set() == true);
		MOVE_CURSOR(10,40);             	
		cout << "Atomic Child Thread 3";
		cout.flush();
		flag.clear();
	}
	return 0;
}

int soln1::main() {
	ClassThread<soln1> C1(this, &soln1::C1, ACTIVE, NULL);			// create the 3 other B1 Child Threads
	ClassThread<soln1> C2(this, &soln1::C2, ACTIVE, NULL);				// create the 3 other B1 Child Threads
	ClassThread<soln1> C3(this, &soln1::C3, ACTIVE, NULL);				// create the 3 other B1 Child Threads
	for (int i = 0; i < 5; i++) {
		while (flag.test_and_set() == true);
		MOVE_CURSOR(5,5);             	// move cursor to cords [x,y] = 5,5
		cout << "Main Atomic Thread";
		cout.flush();
		flag.clear();
	}
	C1.WaitForThread();				// wait for the 3 other B1 Child Threads to end
	C2.WaitForThread();
	C3.WaitForThread();

	MOVE_CURSOR(0, 42);             	// move cursor to cords [x,y] = 5,5
	cout << "Press RETURN for Mutex Solution\n";
	//cout.flush();
	//flag.clear();

	getchar();
	return 0;
}
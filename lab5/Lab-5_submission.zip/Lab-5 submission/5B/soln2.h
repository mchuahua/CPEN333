#ifndef __soln2__
#define __soln2__

#include "rt.h"

class soln2 : public ActiveClass {
public:
	soln2();
	~soln2();
	int __thiscall C1(void* args);
	int __thiscall C2(void* args);
	int __thiscall C3(void* args);

private:
	CMutex* CM;
	int main();

};

#endif // !__soln2__

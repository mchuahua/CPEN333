#include <iostream>
using namespace std;
#include "CSwitch.h"

CSwitch::CSwitch() : state(0) {
	cout << "CSwitch Constructor being called...\n";
}

void CSwitch::print() {
	if (state == 0) {
		cout << "Current Switch State is OFF\n";
	}
	else if (state == 1) {
		cout << "Current Switch State is ON\n";
	}
	else {
		cout << "Invalid Switch State\n";
	}
}

void CSwitch::turnon() {
	state = 1;
}
void CSwitch::turnoff() {
	state = 0;
}

int CSwitch::getstate() {
	return state;
}

CSwitch::~CSwitch() {
	cout << "CSwitch Destructor being called...\n";
}
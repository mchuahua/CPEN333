#ifndef __List__
#define __List__

#include <iostream>
using namespace std;

template <typename T>
struct Node
{
	T value;
	Node* next;
};

template <class T>
class List {
	Node<T> *ptr;

public:
	List() {
		ptr = NULL;
		cout << "List created\n";
	};
	~List() {
		cout << "List Destructor called...\n";
		while (ptr != NULL) Delete();
		cout << "List destroyed\n";
	};
	void Insert(T i) {
		Node<T>* newNode = new Node<T>;
		newNode->value = i;
		newNode->next = NULL;
		Node<T>* temp = ptr;

		if (ptr == NULL) {
			ptr = newNode;
		}
		else {
			while (temp->next != NULL) {
				temp = temp->next;
			}
			temp->next = newNode;
		}
	};
	void Delete() {
		int i = 0;
		Node<T>* temp_ptr = ptr;
		Node<T>* prev_ptr;
		while (temp_ptr->next != NULL) {
			prev_ptr = temp_ptr;
			temp_ptr = temp_ptr->next;
			if (temp_ptr->next == NULL)
				prev_ptr->next = NULL;
			i++;
		}
		if (temp_ptr == ptr) {
			delete temp_ptr;
			ptr = NULL;
			cout << "Pointer Node deleted\n";
			return;
		}
		delete temp_ptr;
		cout << "Deleted Node " << i + 1 << "\n";
	};
	T Get(T i) {
		Node<T>* temp = ptr;
		for (int j = 0; j < i - 1; j++) {
			temp = temp->next;
		}
		return temp->value;
	};
	void print() {
		Node<T>* temp = ptr;
		while (temp->next != NULL) {
			cout << temp->value << " ";
			temp = temp->next;
		}
		cout << temp->value << " \n";
	};
};

#endif // !__List__


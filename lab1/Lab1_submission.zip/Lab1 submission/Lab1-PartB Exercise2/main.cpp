#include "List.h"
#include "CBulb.h"
#include "CSwitch.h"
#include <iostream>
using namespace std;

int main(void) {
	List<int> l2;
	for (int i = 1; i <= 10; i++) {
		l2.Insert(i*10);
	}
	l2.print();

	CBulb b1(100);
	CSwitch s1;
	List<CBulb*> clb1;
	List<CSwitch*> cls1;

	clb1.Insert(&b1);
	cls1.Insert(&s1);

	//compile errors when:
	//clb1.Insert(&s1);
	//cls1.Insert(&b1);
	//clb1.Insert(2);

	cout << "\n\n **Destructors**\n";
	return 0;
}
#include "List.h"
#include <iostream>
using namespace std;

List::List() {
	ptr = NULL;
	cout << "List created\n";
}

List::~List() {
	cout << "List Destructor called...\n";
	int i = 0;
	while (ptr->next != NULL) {
		Delete();
	}
	if (ptr != NULL) {
		Delete();
	}
	cout << "List destroyed\n";
}

void List::Insert(int i) {
	Node* newNode = new Node;
	newNode->value = i;
	newNode->next = NULL;
	Node *temp = ptr;

	if (ptr == NULL) {
		ptr = newNode;
	}
	else {
		while (temp->next != NULL) {

			temp = temp->next;
		}
		temp->next = newNode;
	}
}

void List::Delete() {
	Node* temp = ptr;
	int i = 0;
	if (ptr->next == NULL) {
		delete ptr;
		cout << "Pointer Node deleted\n";
		return;
	}

	while (temp->next->next != NULL) {
		temp = temp->next;
		i++;
	}
	delete temp->next->next;
	temp->next = NULL;
	cout << "Deleted Node " << i+2 <<"\n";
}

int List::Get(int i) {
	Node* temp = ptr;
	for (int j = 0; j < i-1; j++) {
		temp = temp->next;
	}
	return temp->value;
}

void List::print() {
	Node* temp = ptr;
	while(temp->next!=NULL){
		cout << temp->value <<" ";
		temp = temp->next;
	}
	cout << temp->value << " \n";
}
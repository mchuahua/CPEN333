#include <iostream>
using namespace std;
#include "CPullLamp.h"


CPullLamp::CPullLamp(int w1, int w2, int w3) : CLamp3Bulb(w1, w2, w3) {
	cout << "CPullLamp Constructor called... \n";
}

CPullLamp::~CPullLamp() {
	cout << "CPullLamp Destructor called... \n";
}

void CPullLamp::toggle() {
	if (getState() == 0) {
		CLamp3Bulb::LampOn();
	}
	else CLamp3Bulb::LampOff();
}


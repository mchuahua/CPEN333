#include <iostream>
#include "CBulb.h"
#include "CSwitch.h"
#include "CLamp3Bulb.h"
#include "CPullLamp.h"

using namespace std;

int main(void) {
	
	//Exercise 1
	cout << "**EXERCISE 1**\n";

	CBulb cb1(120);	//instantiate object
	cb1.print();
	//cb1.setstate(1);
	cb1.on();	//turn on
	cb1.setwatts(100);	//set watts
	cb1.print();
	cout << "Current Power is "<< cb1.getPower() << " watts.\n";
	cb1.off();
	cb1.print();
	cout << "Current Power is " << cb1.getPower() << " watts.\n";
	cout << "State is: " << cb1.getstate() <<"(1 is ON, 0 is OFF)\n";

	//----------------------------------------------------------------------
	cout << "\n";

	//Exercise 2
	cout << "**EXERCISE 2**\n";

	CSwitch cs1;	//instantiate object
	cs1.turnon();	//turn on
	cs1.print();
	cout << "Current Switch State using getstate is "<< cs1.getstate() <<" (1-ON,0-OFF).\n";	//show getstate
	cs1.turnoff();
	cs1.print();
	cout << "Current Switch State using getstate is " << cs1.getstate() << " (1-ON,0-OFF).\n";	//show getstate											
    //----------------------------------------------------------------------
	cout << "\n";

	//Exercise 3
	cout << "**EXERCISE 3**\n";
	cout << "Wattage assigned to the bulbs: 10,20 and 30 watts respectively.\n";
	CLamp3Bulb cl1(10, 20, 30);
	cl1.print();
	cout << "Current Lamp state is "<< cl1.getState() <<" (1-ON,0-OFF) and "<< cl1.getPower() <<" watts of power is consumed.\n";	//show getstate
	cl1.LampOn();
	cl1.print();
	cout << "Current Lamp state is "<<cl1.getState()<<" (1-ON,0-OFF) and "<< cl1.getPower()<<" watts of power is consumed.\n";	//show getstate
	cl1.LampOff();
	cl1.print();
	cout << "Current Lamp state is " << cl1.getState() << " (1-ON,0-OFF) and " << cl1.getPower() << " watts of power is consumed.\n";	//show getstate
	//----------------------------------------------------------------------
	cout << "\n";
	
	//Exercise 4
	cout << "**EXERCISE 4**\n";
	cout << "New Bulb(70W) created and replacing bulb 3 in lamp. New Lamp power consumption should be 100W\n";
	CBulb* b2 = new CBulb(70);
	b2 = cl1.exchange(b2, 2);
	delete b2;
	cout << "Current Lamp state is " << cl1.getState() << " (1-ON,0-OFF) and " << cl1.getPower() << " watts of power is consumed.\n";
	cl1.LampOn();
	cout << "Current Lamp state is " << cl1.getState() << " (1-ON,0-OFF) and " << cl1.getPower() << " watts of power is consumed.\n";

	//----------------------------------------------------------------------
	cout << "\n";

	//Exercise 5
	cout << "**EXERCISE 5**\n";
	//CLamp3Bulb* cl2 = new CLamp3Bulb(11,12,13);
	CLamp3Bulb cl2(cl1);
	cout << "Current Lamp state is " << cl1.getState() << " (1-ON,0-OFF) and " << cl1.getPower() << " watts of power is consumed.\n";
	CBulb* b3 = new CBulb(100);
	b3 = cl2.exchange(b3, 2);
	delete b3;
	cout << "Current Lamp 1(original) state is " << cl1.getState() << " (1-ON,0-OFF) and " << cl1.getPower() << " watts of power is consumed.\n";
	//cl2.LampOff();
	cout << "Current Lamp 2(copy with exchanged bulb) state is " << cl2.getState() << " (1-ON,0-OFF) and " << cl2.getPower() << " watts of power is consumed.\n";
	//----------------------------------------------------------------------
	cout << "\n";

	//Exercise 6
	cout << "**EXERCISE 6**\n";
	//CLamp3Bulb* cl2 = new CLamp3Bulb(11,12,13);
	CPullLamp cp1(100,100,100);
	//cp1.LampOn();
	cp1.toggle();
	cout << "Current Lamp state is " << cp1.getState() << " (1-ON,0-OFF) and " << cp1.getPower() << " watts of power is consumed.\n";
	
	CBulb* p1 = new CBulb(50);
	p1 = cp1.exchange(p1, 0);
	delete p1;

	cout << "Current Lamp state is " << cp1.getState() << " (1-ON,0-OFF) and " << cp1.getPower() << " watts of power is consumed.\n";
	//cp1.LampOff();
	cp1.toggle();
	cout << "Current Lamp state is " << cp1.getState() << " (1-ON,0-OFF) and " << cp1.getPower() << " watts of power is consumed.\n";

	//----------------------------------------------------------------------
	cout << "\n";



	cout << "\n\n\n***Destructors***\n";
	return 0;
}
#ifndef __CBulb__
#define __CBulb__

class CBulb {
	int state, watts = 0;

public:
	CBulb(); //default
	CBulb(int x); //with watts
	void print();
	//void setstate(int x);
	void on();
	void off();
	int getstate();
	void setwatts(int x);
	int getPower();
	~CBulb();
};


#endif // !__CBulb__
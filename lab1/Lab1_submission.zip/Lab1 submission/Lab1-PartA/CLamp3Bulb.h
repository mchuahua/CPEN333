#ifndef __CLamp3Bulb__
#define __CLamp3Bulb__

#include "CSwitch.h"
#include "CBulb.h"

class CLamp3Bulb {
	CSwitch* cs1;
	CBulb* cb1[3];
	//Exercise 3
	// CBulb cb1[3];
	// CSwitch cs1;
public:
	CLamp3Bulb(int w1, int w2, int w3);
	CLamp3Bulb(const CLamp3Bulb &copy);
	void LampOn();
	void LampOff();
	void print();
	int getState();
	int getPower();
	CBulb* exchange(CBulb* newBulb, int bulbNum);
	~CLamp3Bulb();
};
#endif // !__CLamp3Bulb__

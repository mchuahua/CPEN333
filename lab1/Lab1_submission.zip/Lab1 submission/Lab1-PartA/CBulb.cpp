#include <iostream>
using namespace std;
#include "CBulb.h"

CBulb::CBulb() : state(0) {
	cout<<"Default CBulb Constructor being called...\n";
}

CBulb::CBulb(int x) : state(0), watts(x) {
	cout << "CBulb Constructor(with watts argument) being called...\n";
}

CBulb::~CBulb(){
	cout << "CBulb Destructor being called...\n";
}

void CBulb::print() {
	if (state == 0) {
		cout<<"Current Bulb State is OFF\n";
	}
	else if (state == 1) {
		cout << "Current Bulb State is ON\n";
	}
	else {
		cout << "Invalid Bulb State\n";
	}
	cout << "Current watts is "<<watts<<"\n";
}

void CBulb::on() {
	state = 1;
}

void CBulb::off() {
	state = 0;
}

int CBulb::getstate() {
	return state;
}

void CBulb::setwatts(int x) {
	watts = x;
}

int CBulb::getPower() {
	return state * watts;
}

//void CBulb::setstate(int x) {
	//state = x;
//}


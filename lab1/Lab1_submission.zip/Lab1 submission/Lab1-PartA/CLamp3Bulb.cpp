#include <iostream>
using namespace std;
#include "CLamp3Bulb.h"

CLamp3Bulb::CLamp3Bulb(int w1, int w2, int w3) {
	//Exercise 4 new code
	cs1 = new CSwitch;
	cb1[0] = new CBulb(w1);
	cb1[1] = new CBulb(w2);
	cb1[2] = new CBulb(w3);
	cout << "CLamp3Bulb Constructor being called...\n";

	/* Exercise 3 old code
	cs1.turnoff();

	cb1[0].off();
	cb1[0].setwatts(w1);

	cb1[1].off();
	cb1[1].setwatts(w2);

	cb1[2].off();
	cb1[2].setwatts(w3);
	*/
}

CLamp3Bulb::CLamp3Bulb(const CLamp3Bulb& copy) {
	cout << "CLamp3Bulb Copy Constructor being called...\n";
	cs1 = new CSwitch;
	cb1[0] = new CBulb();
	cb1[1] = new CBulb();
	cb1[2] = new CBulb();
	/* old code
	cs1 = copy.cs1;
	cb1[0] = copy.cb1[0];
	cb1[1] = copy.cb1[1];
	cb1[2] = copy.cb1[2];
	*/
	if (copy.cs1->getstate()) {
		cs1->turnon();
	}
	for (int i = 0; i < 3; i++) {
		cb1[i]->setwatts(copy.cb1[i]->getPower());
		if (copy.cs1->getstate()) {
			cb1[i]->on();
		}
	}
}

CLamp3Bulb::~CLamp3Bulb() {
	cout << "CLamp3Bulb Destructor being called...\n";
	delete cs1;
	delete cb1[0];
	delete cb1[1];
	delete cb1[2];
}

void CLamp3Bulb::LampOn() {
	// Exercise 3
	// cs1.turnon();
	cs1 -> turnon();
	for (int i = 0; i < 3; i++) {
		cb1[i] -> on();
		// Exercise 3
		// cb1[i].on();
	}
}

void CLamp3Bulb::LampOff() {
	// Exercise 3
	// cs1.turnoff();
	cs1 ->turnoff();
	for (int i = 0; i < 3; i++) {
		cb1[i] -> off();
		// Exercise 3
		// cb1[i].off();
	}
}

int CLamp3Bulb::getState() {
	//Ex 3
	//return cs1.getstate()
	return cs1->getstate();
}

int CLamp3Bulb::getPower() {
	int power = 0;
	for (int i = 0; i < 3; i++) {
		//Ex 3
		//power+= cb1[i].getPower();
		power+=cb1[i] -> getPower();
	}
	//Ex 3
	//return cs1.getstate() * power;
	return cs1->getstate() * power;
}

void CLamp3Bulb::print() {
	//Ex 3
	// cs1.getstate() instead of pointers
	if (cs1->getstate() == 0) {
		cout << "Current Lamp State is OFF\n";
	}
	else if (cs1->getstate() == 1) {
		cout << "Current Lamp State is ON\n";
	}
	else {
		cout << "Invalid Lamp State\n";
	}
}

CBulb* CLamp3Bulb::exchange(CBulb* newBulb, int bulbNum) {
	if (cs1->getstate() == 1) {
		newBulb->on();
	}
	CBulb* temp = cb1[bulbNum];
	cb1[bulbNum] = newBulb;
	newBulb = temp;

	return newBulb;
}
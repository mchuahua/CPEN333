#ifndef __List__
#define __List__

struct Node {
	int value;
	Node* next;
};

class List {
	Node* ptr;

public:
	List();
	~List();
	void Insert(int i);
	void Delete();
	int Get(int i);
	void print();
};

#endif // !__List__
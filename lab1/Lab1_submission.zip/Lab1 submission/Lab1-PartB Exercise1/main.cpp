#include "List.h"
#include <iostream>
using namespace std;

int main(void) {
	int x;
	List l1;

	l1.Insert(10);
	l1.print();
	l1.Delete();
	
	cout << "\n";
	List l2;
	for (int i = 1; i <= 10; i++) {
		l2.Insert(i*10);
	}
	l2.print();

	cout << "What Node are you interested in? ";
	cin >> x;
	cout <<"Node at position has value: "<< l2.Get(x) <<"\n";

	cout << "\nTest deleting 2 values:\n";
	l2.print();
	l2.Delete();
	l2.Delete();
	l2.print();

	cout << "\n\n **Destructors**\n";
	return 0;
}
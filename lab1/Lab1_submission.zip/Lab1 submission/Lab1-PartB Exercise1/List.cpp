#include "List.h"
#include <iostream>
using namespace std;

List::List() {
	ptr = NULL;
	cout << "List created\n";
}

List::~List() {
	cout << "List Destructor called...\n";
	while (ptr != NULL) {
		Delete();
	}
	cout << "List destroyed\n";
}

void List::Insert(int i) {
	Node* newNode = new Node;
	newNode->value = i;
	newNode->next = NULL;
	Node *temp = ptr;

	if (ptr == NULL) {
		ptr = newNode;
	}
	else {
		while (temp->next != NULL) {
			temp = temp->next;
		}
		temp->next = newNode;
	}
}

void List::Delete() {
	int i = 0;
	Node* temp_ptr = ptr;
	Node* prev_ptr;
	while (temp_ptr->next != NULL) {
		prev_ptr = temp_ptr;
		temp_ptr = temp_ptr->next;
		if (temp_ptr->next == NULL)
			prev_ptr->next = NULL;
		i++;
	}
	if (temp_ptr == ptr) {
		delete temp_ptr;
		ptr = NULL;
		cout << "Pointer Node deleted\n";
		return;
	}
	delete temp_ptr;
	cout << "Deleted Node " << i + 1 << "\n";
}
/* old
	if (ptr == NULL) {
		return;
	}
	Node* temp = ptr;
	int i = 0;
	if (ptr->next == NULL) {
		delete ptr;
		cout << "Pointer Node deleted\n";
		ptr = NULL;
		return;
	}
	while (temp->next->next != NULL) {
		temp = temp->next;
		i++;
	}
	delete temp->next->next;
	temp->next = NULL;
	cout << "Deleted Node " << i+2 <<"\n";
*/

int List::Get(int i) {
	Node* temp = ptr;
	for (int j = 0; j < i-1; j++) {
		temp = temp->next;
	}
	return temp->value;
}

void List::print() {
	Node* temp = ptr;
	while(temp->next!=NULL){
		cout << temp->value <<" ";
		temp = temp->next;
	}
	cout << temp->value << " \n";
}